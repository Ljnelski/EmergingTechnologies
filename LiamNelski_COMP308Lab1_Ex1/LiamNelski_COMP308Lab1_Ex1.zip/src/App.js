import { useState } from "react";
import "./App.css";
import CommentsPage from "./pages/comments";
import LoginPage from "./pages/login";
import ThankYouPage from "./pages/thank-you";

function App() {
  const [studentData, setStudentData] = useState(null);
  const [submissionData, setSubmissionData] = useState(null);

  if (validSubmission(submissionData)) {
    return <ThankYouPage email={studentData.email} comment={submissionData.courseComment}></ThankYouPage>
  } else if (validLogin(studentData)) {
    return <CommentsPage email={studentData.email} onSubmit={setSubmissionData}></CommentsPage>;
  } else {
    return (
      <div className="app-body">
        <LoginPage onLogin={setStudentData}></LoginPage>
      </div>
    );
  }
}

function validLogin(loginData) {
  return loginData?.email && loginData?.password;
}

function validSubmission(submissionData) {
  return submissionData?.courseCode && submissionData?.courseName && submissionData?.courseComment && toString(submissionData?.age) && submissionData?.country;
}

export default App;
