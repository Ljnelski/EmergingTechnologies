import React, { useState, useRef } from "react";

import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from 'react-bootstrap/Button';


function LoginPage({onLogin}) {

  const emailRef = useRef();
  const passwordRef = useRef();

  const handleLogin = () => {
    onLogin({email: emailRef.current.value, password: passwordRef.current.value})
  }

  return (
    <Container fluid="sm">
      <h2>Login to evaluate the course</h2>
      <br></br>
      <Row xs={6}>
        <Col><h5>Email: </h5></Col>
        <Col>
          <input type="email" ref={emailRef}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col><h5>Password: </h5></Col>
        <Col>
          <input type="password" ref={passwordRef}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col></Col>
        <Col>
          <Button className="w-100" onClick={handleLogin}>Login</Button>
        </Col>
      </Row>
    </Container>
  );
}

export default LoginPage;
