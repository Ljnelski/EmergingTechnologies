function ThankYouPage({ email, comment }) {
  return (
    <>
      <h2>Thank you for your submission! {email}</h2>
      <p>We apprciate your comment: {comment}</p>,
    </>
  );
}

export default ThankYouPage;
