import { useRef } from "react";
import Button from "react-bootstrap/esm/Button";
import Col from "react-bootstrap/esm/Col";
import Container from "react-bootstrap/esm/Container";
import Row from "react-bootstrap/esm/Row";

function CommentsPage({ email, onSubmit }) {
  const codeRef = useRef();
  const nameRef = useRef();
  const commentRef = useRef();
  const ageRef = useRef();
  const countryRef = useRef();

  

  const handleSubmit = () => { 
    onSubmit({
        courseCode: codeRef.current.value,
        courseName: nameRef.current.value,
        courseComment: commentRef.current.value,
        age: ageRef.current.value,
        country: countryRef.current.value,
      });
  };

  return (
    <Container fluid="sm">
      <br></br>
      <br></br>
      <Row xs={6}>
        <Col>
          <h5>Course Code:</h5>
        </Col>
        <Col>
          <input ref={codeRef}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col>
          <h5>Course Name:</h5>
        </Col>
        <Col>
          <input ref={nameRef}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col>
          <h5>Student Email:</h5>
        </Col>
        <Col>
          <input type="email" value={email}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col>
          <h5>Your Comments:</h5>
        </Col>
        <Col>
          <textarea type="text" ref={commentRef}></textarea>
        </Col>
      </Row>
      <Row xs={6}>
        <Col>
          <h5>Student Age</h5>
        </Col>
        <Col>
          <input type="number" ref={ageRef}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col>
          <h5>Student Country</h5>
        </Col>
        <Col>
          <input type="text" ref={countryRef}></input>
        </Col>
      </Row>
      <Row xs={6}>
        <Col></Col>
        <Col>
          <Button className="w-100" variant="success" onClick={handleSubmit}>
            Submit
          </Button>
        </Col>
      </Row>
    </Container>
  );
}

export default CommentsPage;
