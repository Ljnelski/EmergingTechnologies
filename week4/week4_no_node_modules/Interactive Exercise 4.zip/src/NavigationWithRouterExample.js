import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect,
  Routes,
} from "react-router-dom";
//
// This app requires react-bootstrap and bootstrap installed:
//    npm install react-bootstrap bootstrap
//
import "bootstrap/dist/css/bootstrap.min.css";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import Container from "react-bootstrap/Container";
import Calculator from "./TemperatureConversionExample";
import FunctNamingFormApp from "./FunctNameFormApp";
import "./App.css";
//

function NavigationWithRouterExample() {
  return (
    <Router>
      <Navbar bg="primary" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="home">
            React App - Navigation with Routing
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link as={Link} to="/home">
                Home
              </Nav.Link>
              <Nav.Link as={Link} to="/about">
                About Routing
              </Nav.Link>
              <Nav.Link as={Link} to="/list">
                User List
              </Nav.Link>
              <Nav.Link as={Link} to="/form">
                Name & Course Form
              </Nav.Link>
              <Nav.Link as={Link} to="/calculator">
                Temperature Calculator
              </Nav.Link>
              <Nav.Link as={Link} to="/simulation">
                Class I
              </Nav.Link>
              <Nav.Link as={Link} to="/sustainability">
                Class II
              </Nav.Link>
              <Nav.Link as={Link} to="/special-topics">
                Class III
              </Nav.Link>
              <Nav.Link as={Link} to="/advanced-graphics">
                Class IV
              </Nav.Link>
              <Nav.Link as={Link} to="/software-project-II">
                Class V
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <div>
        <Routes>
          <Route index element={<Home />} />
          <Route path="home" element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="list" element={<List />} />
          <Route path="form" element={<FunctNamingFormApp />} />
          <Route path="calculator" element={<Calculator />} />
          <Route path="simulation" element={<Simulation />} />
          <Route path="sustainability" element={<Sustainability />} />
          <Route path="special-topics" element={<SpecialTopics />} />
          <Route path="advanced-graphics" element={<AdvancedGrapics />} />
          <Route path="software-project-II" element={<SoftwareProjectII />} />
        </Routes>
      </div>
    </Router>
  );
}
//
export default NavigationWithRouterExample;

function Home() {
  return <h2>Home</h2>;
}

function About() {
  return <h2>About</h2>;
}

function List() {
  return <h2>List of Users</h2>;
}

function Simulation() {
  return <h2>Simulation Design</h2>;
}

function Sustainability() {
  return <h2>Energy and Enviromental Sustainability</h2>;
}

function SpecialTopics() {
  return <h2>Special Topics in gaming</h2>;
}

function AdvancedGrapics() {
  return <h2>Advanced Grapics</h2>;
}

function SoftwareProjectII() {
  return <h2>Software Project II</h2>;
}
