import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//
//import App from './App';
//import App from'./FunctNameFormApp';
//import App from './NameForm';
//import App from './FlavorForm';
//import App from './FunctFlavorFormApp';
//import App from './Reservation';
//import App from './FunctReservationFormApp';
//import App from'./FunctLoginForm'

//import App from './TemperatureConversionExample';
//import App from './BasicRoutingTest';
//import App from './DynamicRoutingExample';
//import App from './NestedRoutingExample';
//import App from './ProtectedRoutesExample';
//import App from './TernaryStatementTest'
//import App from './BasicRoutingExample';
//import App from './LiftStateUp2'
import App from './NavigationWithRouterExample'


ReactDOM.render(<App />, document.getElementById('root'));
