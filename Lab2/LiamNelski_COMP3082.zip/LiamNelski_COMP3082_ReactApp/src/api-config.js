const connectionString = "http://localhost:4200"
const apiConnection = {
    student: connectionString + "/student"
}

export default apiConnection;