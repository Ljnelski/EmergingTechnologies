import Car from "./vehicles.js"
import Vehicle from "./vehicles.js"
//
let car = new Car('blue');
car.toString(); 
console.log(car instanceof Car); 
console.log(car instanceof Vehicle);
