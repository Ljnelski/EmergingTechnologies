const name = "Tallac";
const elevation = 9738;
const funHike = { name, elevation }; //oposite of destructuring
console.log(funHike); // {name: "Tallac", elevation: 9738}
// name and elevation are now keys of the funHike object.
