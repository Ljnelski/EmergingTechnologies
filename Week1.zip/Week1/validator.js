//exporting bindings -  live connections to values
export let flag = false;
export function touch() {
    flag = true;
}
